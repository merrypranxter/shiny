# ✦ SHINE IS A STRUCTURE

A maximalist design system for generative shiny/sparkle/glitter/fractal-optic effects.

> The normal mistake is to think shine = a white highlight pasted on top.  
> No. Better rule: **SHINE IS A STRUCTURE.**

## What This Is

A curated grimoire of optical design principles, generative math systems, code patterns, and ready-to-build showcase concepts for creating shine that feels *designed* — not decorated.

## Core Doctrine

Shine can be:
- a **seam**
- a **vein**
- a **crack**
- a **woven path**
- a **pressure ridge**
- a **film** sitting on a dull host
- a **grid of light** under skin
- a **buried geometry** that leaks brilliance
- a **tessellation** whose edges are emitting
- a matte thing interrupted by **impossible gloss**

So instead of "make it shiny," think:
- What part of the object is **carrying** the shine?
- What **material logic** decides where shine lives?
- Is the shine skin-deep, embedded, wet, crystalline, metallic, prismatic, electric, oily, glittery, holographic, mirror-like?

## Repo Structure

```
├── README.md                 ← You are here
├── DOCTRINE.md               ← Core philosophy + master rules
├── VOCABULARY.md             ← Shine carriers, materials, hosts, behaviors
├── DESIGN-FORMULAS.md        ← 4 quick generator formulas
├── systems/                  ← 20 deep-dive shiny system modules
│   ├── 01-matte-host-brilliant-veins.md
│   ├── 02-tessellation-woven-light.md
│   ├── 03-kintsugi-crack-seam-shine.md
│   ├── 04-buried-subsurface-shine.md
│   ├── 05-glitter-ecology-clusters.md
│   ├── 06-metallic-gradient-maps.md
│   ├── 07-shine-as-weather-contours.md
│   ├── 08-infrastructure-brilliance.md
│   ├── 09-shine-as-embroidery.md
│   ├── 10-wet-shine-vs-dry-shine.md
│   ├── 11-shine-as-anatomy.md
│   ├── 12-shine-as-repair-damage.md
│   ├── 13-shine-as-woven-structure.md
│   ├── 14-shine-as-residue-contamination.md
│   ├── 15-shine-as-language-symbol.md
│   ├── 16-shine-as-object-logic.md
│   ├── 17-shine-as-costume-fashion.md
│   ├── 18-shine-as-map-topography.md
│   ├── 19-shine-as-caustic-projection.md
│   └── 20-shine-as-metallic-gradient-sculpture.md
├── showcase-builds/          ← 25 specific buildable concepts
│   ├── 01-glitter-circulatory-system.md
│   ├── 02-opal-nervous-system.md
│   ├── 03-rhinestone-lymph-nodes.md
│   ├── 04-metallic-vein-stone.md
│   ├── 05-sequined-skeleton.md
│   ├── 06-holographic-kintsugi-storm.md
│   ├── 07-glitter-scar-tissue.md
│   ├── 08-chrome-infection-map.md
│   ├── 09-polarized-stress-fractures.md
│   ├── 10-glitter-erosion-canyon.md
│   ├── 11-penrose-light-loom.md
│   ├── 12-hologram-basketweave.md
│   ├── 13-voronoi-chrome-grout.md
│   ├── 14-fiber-optic-quilt.md
│   ├── 15-metallic-lace-trellis.md
│   ├── 16-glitter-weather-front.md
│   ├── 17-mirror-dust-dunes.md
│   ├── 18-caustic-rainforest.md
│   ├── 19-oil-slick-pond-skin.md
│   ├── 20-opal-moss.md
│   ├── 21-glitter-mold-bloom.md
│   ├── 22-chrome-pollen.md
│   ├── 23-lip-gloss-oil-spill.md
│   ├── 24-sequin-mildew.md
│   └── 25-foil-rust.md
├── code-snippets/            ← Extracted JS/GLSL code blocks
│   ├── vein-generators.js
│   ├── tessellation-renderers.js
│   ├── crack-systems.js
│   ├── buried-shine.js
│   ├── glitter-ecology.js
│   ├── metallic-palettes.js
│   ├── weather-systems.js
│   ├── infrastructure-networks.js
│   ├── embroidery-stitches.js
│   ├── wet-dry-shine.js
│   ├── anatomy-systems.js
│   ├── repair-damage.js
│   ├── woven-structures.js
│   ├── residue-contamination.js
│   ├── language-symbols.js
│   ├── object-logic.js
│   ├── costume-fashion.js
│   ├── map-topography.js
│   ├── caustic-projection.js
│   └── metallic-sculpture.js
├── cross-mutations/          ← Hybrid concept pairings
├── math-systems/             ← Math/system reference docs
├── prompts/                  ← Ready-to-use prompt formulas
└── shader-translations/      ← GLSL + RepoScripter instructions
```

## How to Use

1. **Read `DOCTRINE.md`** — internalize the core philosophy
2. **Browse `systems/`** — find the optical direction that fits your project
3. **Check `showcase-builds/`** — grab a specific concept and its code
4. **Reference `math-systems/`** — understand the generative math behind it
5. **Use `prompts/`** — drop into your generative pipeline
6. **Cross-breed** — combine systems for maximum weirdness

## The 5 Strongest Directions (Start Here)

1. **Matte host + brilliant veins** — contrast of dead surface vs live optical infrastructure
2. **Tessellation woven from light** — geometry becomes shine-carrying infrastructure
3. **Kintsugi / crack / seam shine** — damage made beautiful and electrically alive
4. **Buried shine under cloudy material** — subsurface optical magic
5. **Clustered glitter ecology** — sparkle with population structure, not uniform decoration

## Master Render Pipeline

For any shiny system, the strong render pipeline is:

1. Draw quiet host surface
2. Generate a structural field / network / path
3. Assign optical material behavior to that structure
4. Add hierarchy:
   - broad soft sheen
   - medium directional shine
   - tiny sparkle events
   - rare explosive highlights
5. Let interaction act as light source / pressure / scanner

## Design Formulas (Quick Generators)

| Formula | Pattern | Example |
|---------|---------|---------|
| F1 | `[dull host] + [branching shiny system]` | velvet + opal veins |
| F2 | `[tessellated geometry] + [shine medium] + [wrong behavior]` | Penrose + fiber-optic + leaks color like sap |
| F3 | `[fracture/seam logic] + [luxury optical material]` | crack map + pearl glaze |
| F4 | `[soft matte body] + [buried luminous structure]` | silicone flesh + glitter veins |

## Wet Shine vs Dry Shine

| Wet | Dry |
|-----|-----|
| continuous, glossy, flowing, reflective, high bloom | particulate, dusty, powdery, flaky, granular, intermittent |

A design gets better when both are present.

## License

This is a living document. Fork it, mutate it, make it weirder.

---

*"Shiny design is not about covering a thing in gloss. It is about deciding where brilliance lives."*
